# Grand Line Trainer v2.0 UI Overhaul

Upload `index.html`, `version.json`, and `legacy/Grand-Line-Trainer-OFFLINE.html` to the repository.

Tap your Deck to draw and Trash to inspect. Stage and Event zones are placeholders; no placement/effect rules were added. Existing saves remain in the same format. Export a backup before upgrading.
